<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/switcher.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
</head>
<body>

<div id="navbar">
  
  <a href="#default" id="logo"><img src="images/logo.png"></a>
  <div id="navbar-right">
    <li>
    <a href="#contact">HOME</a>
    <a href="#contact">SERVICE</a>
    <a href="#contact">PORTFOLIO</a>
    <a href="#contact">TESTIMONAL</a>
    <a href="#contact">PRICE</a>
    <a href="#about">CONTACT</a>
    <a href="login.php">Login</a>
    </li>
  </div>
 
</div>