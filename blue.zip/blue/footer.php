       <!--Footer part starts-->
       <div class="Footerp">
                          <div class="container">
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                              <div class="logopart">
                                <h4>
                                  <a href="#">
                                    <img src="images/logo.png">
                                  </a>
                                </h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias ullam numquam repudiandae repellat ex autem voluptas vel esse quo excepturi!<br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem, repellendus.</p>
                              </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                              <div class="logopart1">
                                <h4>Contact</h4>
                                <ul>
                                  <li>
                                    <a href="#">About Us</a>
                                  </li>
                                  <li>
                                    <a href="#">Press</a>
                                  </li>
                                  <li>
                                    <a href="#">Jobs</a>
                                  </li>
                                  <li>
                                    <a href="#">Terms And Condition</a>
                                  </li>
                                </ul>
                                  
                               </div>
                            </div>
                            <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                              <div class="logopart2">
                                <h4> newsletter signup </h4>            
                               
                                <p>You will be among the first to know about hot new software and great deals on stuff to enhance and promote</p>


                                <form action="#" method="post" class="subscribe-form wow animated fadeInUp">
                                <div class="input-field">
                                 <input type="email" class="subscribe form-control" placeholder="Enter Your Email...">
                                <button type="submit" class="submit-icon">
                                <i class="fa fa-envelope"></i>
                                 </button>
                                </div>
                                 </form>

                              </div>
                            </div>                            
                            
                          </div>
                        </div>
                        <div class="bottompage">
                        <div class="container">
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12">
                              <div class="copyright">
                                <p>
                                  COPYRIGHT © 2016 , BLUE PRO | DIGITAL AGENCY                                                           
                                </p>
                              </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12">
                              <div class="copyright1">
                               <p>
                                Design and Developed By
                               <a href="#">Themefisher</a>
                               </p>
                              </div>
                            </div>
                          </div>
                          </div>

       <!--Footer part end-->



<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>




<script>
// When the user scrolls down 80px from the top of the document, resize the navbar's padding and the logo's font size
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.getElementById("navbar").style.padding = "20px 10px";
    document.getElementById("logo").style.fontSize = "25px";
  } else {
    document.getElementById("navbar").style.padding = "28px 10px";
    document.getElementById("logo").style.fontSize = "35px";
  }
}
</script>

</body>
</html>