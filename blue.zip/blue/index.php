<?php
include 'head.php';
?>

<!--slide start-->

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="images/slider-1.jpg" ;>
          <div class="carousel-caption">
          
          <h1><b> Amazing Business Template For Your Business
                                </b></h1>
          <p>We rejoice you have actually discovered our church we before youwill locate us to be an enWe rejoice you have actually discovered our church we before youwill locate us to be an en We rejoice you have actually discovered our church we before youwill locate us to be an en</p>
          <a href="" class="learnmore">Join us</a>
        </div>
      </div>

      <div class="item">
        <img src="images/slider-2.jpg";>
          <div class="carousel-caption">
          
          <h1><b> Amazing Business Template For Your Business
                                </b></h1>
          <p>We rejoice you have actually discovered our church we before youwill locate us to be an enWe rejoice you have actually discovered our church we before youwill locate us to be an en We rejoice you have actually discovered our church we before youwill locate us to be an en</p>
          <a href="" class="learnmore">Join us</a>
        </div>
      </div>
    
      <div class="item">
        <img src="images/slider-3.jpg";>
          <div class="carousel-caption">
         <h1><b> Amazing Business Template For Your Business
                                </b></h1>
          <p>We rejoice you have actually discovered our church we before youwill locate us to be an enWe rejoice you have actually discovered our church we before youwill locate us to be an en We rejoice you have actually discovered our church we before youwill locate us to be an en</p>
          <a href="" class="learnmore">Join us</a>
        </div>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

 <!--slide end-->

  <!--body 1 start-->
            <div class="best">
              <h2>Best Features</h2>
              <h4></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>
            </div>
            <div class="bfeature">
              <div class="container">
                <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                  <div class="spot">
                    <h4>The Perfect Spot</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit<br>Accusantium repellendus, ut saepe, consequatur dolor eum!</p>
                    <ul>
                      <li>
                        <i class=" fa fa-check"></i>
                        Norman Copenhagen focuses on challenging
                      </li>
                      <li>
                        <i class=" fa fa-check"></i>
                        The challenge was melting
                      </li>
                      <li>
                        <i class=" fa fa-check"></i>
                        We thought air purifier
                      </li>
                      <li>
                        <i class=" fa fa-check"></i>
                        Front face is coated with fabric for a familia
                      </li>
                      <li>
                        <i class=" fa fa-check"></i>
                        Developing Belyse, I thought the strong characters
                      </li>

                    </ul>
                  </div>
                </div>
                 <div class="col-lg-8 col-sm-8 col-md-8 col-xs-12">
              <img src="images/features.jpg" style="width: 100%;">
            </div>
                
              </div>
            </div>
           


  <!--body 1 end-->
  <!--what you want part starts-->

               <div class="what-want">
                <div class="container">
                 <h2>WHAT DO YOU WANNA KNOW</h2>
                 <h4> </h4>
                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>
                 <img src="images/prototype.jpg">
                 <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate magni, delectus nam qui deserunt perspiciatis,<br> voluptates ratione. Atque voluptate qui dolor veniam voluptatibus, itaque odit, ullam ipsam exercitationem et ex.</h5>
                 <a href="#">Learn More</a>
                 </div>
               </div>


  <!--what you want part starts-->
  <!-- services part starts-->
                <div class="ser-part">
                  <div class="container">
                    <h2>SERVICES</h2>
                    <h4></h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-laptop"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-check-circle"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-book "></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-send"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-laptop"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-check-circle"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-book"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                    <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12">
                      <div class="ser-icon">
                        <i class="fa fa-send"></i>
                        <h3>FULLY RESPONSIVE</h3>
                        <p>Lorem Ipsum is simply dummy text<br> of the printing and typesetting<br> industry.</p>                        
                      </div>                      
                    </div>
                  </div>
                </div>
  <!-- services part end-->
        
  <!--video part starts-->
                        <section class="video-bg">
                          <div class="overlay"></div>
                           <div class="container">
                            <div class="row">
                             <div class="col-md-offset-2 col-md-8">
                              <div class="section-title text-center white">
                               <h2>FEATURED PROJECTS</h2>
                                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                              </div>
                               <div class="modal-section text-center">
                                <a href="#" data-toggle="modal" data-target="#video-modal" class="video-popup-button">
                                <i class="fa fa-play"></i>
                                </a>
                                  <div class="modal fade" id="video-modal" tabindex="-1" role="dialog">
                                   <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                     <div class="modal-header">
                                       <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                     </div>
                                      <div class="modal-body">
                                       <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/u7mhxWKZovc"></iframe>
                                       </div>
                                       </div>
                                      </div>
                                  </div>
                               </div>
                             </div>
                             <p>Curabitur nec scelerisque nulla, non pharetra sapien. Praesent ac odio dolor. Pellentesque commodo erat justo, ac facilisis arcu fringilla finibus.</p>
                           </div>
                         </div>
                       </div>
      </section>
                     
   <!--video part end-->  

   <!--image hover starts-->
                 <div class="fproject">
                   
                     <h2>FEATURED PROJECTS</h2>
                     <h4></h4>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                  
                 </div>

                 <div class="himage">
                  
                    <ul>
                      <li>
                        <a href="#">All</a> 
                      </li>
                      
                      <li> 
                        <a href="#">Photoshop</a> 
                      </li> 
                       
                      <li>
                        <a href="#">Responsive</a> 
                      </li>
                          
                      <li>
                        <a href="#">WordPress</a> 
                      </li>
                       
                      <li>
                        <a href="#">Illustrator</a> 
                      </li>
                       
                    </ul>
                    
                 </div>

   <!--image hover end-->
   <!--video part starts-->
   <!--video part end-->

  <!--paragaph parts starts-->
            
                <div class="slideshow-container"style="background-image:url(images/testimonial.jpg)">

                  <div class="mySlides">
                   <div class="say">
                    <h2>WHAT PEOPLE SAY</h2>
                     <h6>------- </h6>
                     <img src="images/member-1.jpg"><br>
                      <i class="fa fa-quote-left "></i>
                      <span>Katty Flower</span>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore<br> magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo<br> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                      <div class="sright">
                        <i class="fa  fa-quote-right "></i>
                      </div>
                    </div>
                  </div>

                 <div class="mySlides">
                   <div class="say">
                    <h2>WHAT PEOPLE SAY</h2>
                     <h6>------- </h6>
                     <img src="images/member-1.jpg"><br>
                      <i class="fa fa-quote-left "></i>
                      <span>Katty Flower</span>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore<br> magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo<br> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                      <div class="sright">
                        <i class="fa  fa-quote-right "></i>
                      </div>
                    </div>
                  </div>
                  <div class="mySlides">
                   <div class="say">
                    <h2>WHAT PEOPLE SAY</h2>
                     <h6>------- </h6>
                     <img src="images/member-1.jpg"><br>
                      <i class="fa fa-quote-left "></i>
                      <span>Katty Flower</span>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore<br> magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo<br> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                      <div class="sright">
                        <i class="fa  fa-quote-right "></i>
                      </div>
                    </div>
                  </div>

                     <a class="prev" onclick="plusSlides(-1)">❮</a>
                     <a class="next" onclick="plusSlides(1)">❯</a>

                  </div>

                  <div class="dot-container">
                    <span class="dot" onclick="currentSlide(1)"></span> 
                    <span class="dot" onclick="currentSlide(2)"></span> 
                    <span class="dot" onclick="currentSlide(3)"></span> 
                  </div>
                </div>

     <!--paragaph parts end-->

     <!--Price part starts-->
            <div class="price">
             <div class="container">
               <h2>PRICE</h2>
                  <h4></h4>
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>

                   <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                     <div class="gold1">
                       <h3>Silver</h3>
                       <div class="value1">
                       <span>$</span>
                       <span>24,35</span><br><br>
                       <span>months</span>
                        </div>
                        <ul>
                          <li>24/7 Tech Suport</li>
                          <li>Unlimite Uploads</li>
                          <li>Unlimited Email Accounts</li>
                          <li>Cloud Storage</li>
                          <li>
                            <a href="#">Sign in</a>
                          </li>
                        </ul>

                     </div>
                   </div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                     <div class="gold">
                       <h3>Silver</h3>
                       <div class="value">
                       <span>$</span>
                       <span>50,00</span><br><br>
                       <span>months</span>
                        </div>
                        <ul>
                          <li>24/7 Tech Suport</li>
                          <li>Unlimite Uploads</li>
                          <li>Unlimited Email Accounts</li>
                          <li>Cloud Storage</li>
                          <li>
                            <a href="#">Sign in</a>
                          </li>
                        </ul>

                     </div>
                   </div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
                     <div class="gold1">
                       <h3>Silver</h3>
                       <div class="value1">
                       <span>$</span>
                       <span>123,12</span><br><br>
                       <span>months</span>
                        </div>
                        <ul>
                          <li>24/7 Tech Suport</li>
                          <li>Unlimite Uploads</li>
                          <li>Unlimited Email Accounts</li>
                          <li>Cloud Storage</li>
                          <li>
                            <a href="#">Sign in</a>
                          </li>
                        </ul>

                     </div>
                   </div>

            </div>
          </div>
      <!--Price part end-->
      <!--Follow part starts-->

             <div class="followus">
              <div class="bimages">
              <div class ="container">
               <h2>Follow Us</h2>
               <h4></h4>
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>
                   <div class="socialicon">

                   <ul>
                     <li>
                       <a href="#">
                         <i class="fa fa-facebook"></i>
                       </a>
                     </li>
                     <li>
                       <a href="#">
                         <i class="fa fa-twitter"></i>
                       </a>
                     </li>
                     <li>
                       <a href="#">
                         <i class="fa fa-soccer-ball-o"></i>
                       </a>
                     </li>
                     <li>
                       <a href="#">
                         <i class="fa fa-instagram"></i>
                       </a>
                     </li>
                   </ul>
                   </div>
                 </div>
                 </div>
             </div>

      <!--Follow part end-->
      <!--Contact part starts-->
                <div class="contact">
                  <div class="container">
                     <h2>Follow Us</h2>
                     <h4></h4>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Accusantium repellendus, ut saepe, consequatur dolor eum!.</p>
                       <div class="col-md-8 col-sm-8 col-lg-8 col-xs-12">
                           
                            <div class="formpart">

                            <form>
  
                             
                             <h3><b>SEND US A MESSAGE</b></h3>
                              <hr>

                              <label for=""></label>
                              <input type="text" placeholder="Yourname" name="Yourname" id="Yourname" required>

                              <label for="email"></label>
                              <input type="text" placeholder="Enter Email" name="email" id="email" required>

                              <label for="email"></label>
                              <input type="text" placeholder="Subject" name="Subject" id="Subject" required>

                              <label for="email"></label>
                              <input type="text" placeholder="Your Message" name="you Message" id="email" required>

                               

                            <button type="submit" class="registerbtn">Register</button>
                                             
                             
                             </form>
                              </div>
                              </div>
                              <div class="col-md-4 col-sm-4 col-lg-4 col-xs-12">
                                <div class="conpart">
                                  <h3>OUR ADDRESS</h3>
                                  <p>
                                    <i class="fa fa-home">                                     
                                    </i>
                                    Phoenix Inc.
                                    <span>PO Box 345678</span>
                                    <span>Little Lonsdale St, Melbourne </span>
                                    <span>Australia</span><br>
                                  </p>
                                  <p>
                                    <i class="fa fa-phone ">                                   
                                    </i>
                                    Phone: (415) 124-5678 
                                  </p>
                                  <p>
                                    <i class="fa fa-envelope-o">                               
                                    </i>
                                    website@yourname.com 
                                  </p>
                                </div>
                              </div>
                    
                  </div>
                </div>

       <!--Contact part end-->

<?php require 'footer.php'; ?>